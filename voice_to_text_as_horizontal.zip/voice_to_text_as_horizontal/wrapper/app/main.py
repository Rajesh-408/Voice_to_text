# import os
# os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
# import os, sys
# CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(os.path.dirname(CURRENT_DIR))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from app.bridge_routes import router as wrapper_router
# from faster_whisper_api.app.routes import router as transcribe_router
# from entity_extraction_groq.app.routers import router as entity_router

from fastapi import APIRouter, FastAPI

app = FastAPI()
# internal_router = APIRouter()
# users_router = APIRouter()

# @users_router.get("/users/")
# def read_users():
#     return [{"name": "Rick"}, {"name": "Morty"}]

# internal_router.include_router(users_router)
# app.include_router(internal_router)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Accept", "Content-Type"],
)

# app.include_router(transcribe_router)
# app.include_router(entity_router)

app.include_router(wrapper_router)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)