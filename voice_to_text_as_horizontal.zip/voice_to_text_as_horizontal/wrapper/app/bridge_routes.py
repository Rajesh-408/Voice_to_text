from fastapi import APIRouter, HTTPException, Header, UploadFile, File
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import requests
from sqlalchemy import Column, Integer, String, DateTime, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import logging, os, traceback, uuid


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router=APIRouter()
PATH = "C:/Applicationlogs" 
os.makedirs(PATH,exist_ok=True)
dbpath = os.path.join(PATH, 'test.db')
DATABASE_URL = f"sqlite:///{dbpath}"
txtpath = os.path.join(PATH, 'logger.txt')

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Log(Base):
    __tablename__ = "logs"
    trace_id = Column(String, index=True)
    apiname = Column(String, index=True)
    id = Column(String , primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String, index=True)
    message = Column(String, index=True)

Base.metadata.create_all(bind=engine)

def log_to_db(id, trace_id , app_name,line_info, level, message,):
    try:
        with SessionLocal() as db:
            time = datetime.now()
            log_entry = Log(trace_id=trace_id, apiname=app_name,id=str(uuid.uuid4()), timestamp=time, level=level, message=str(message))
            format = f'{trace_id}-------{app_name}-------{time}-------{level}-------line_no:{line_info}-------{message}\n'
            with open(txtpath, 'a') as file:
                file.write(format)
            db.add(log_entry)
            db.commit()
    except Exception as e:
        print(f"An error occurred: {e}")


@router.post("/combined_endpoint/{id}")
async def combined_endpoint(id: int, file: UploadFile = File(...),trace_id: str = Header(None)):
    header = {'trace_id': trace_id}
    logger.info(f"trace_id for this request : {trace_id}")
    transcription_url="http://faster_whisper_api:8000/transcribe/"
    file_contents = {"file": (file.filename, await file.read(), file.content_type)}
    try:
        transcription_result = requests.post(transcription_url, files=file_contents, headers=header)
        # transcription_result.raise_for_status()
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id,"faster_whisper_api",trace_str, 'SUCCESS', transcription_result)
        logger.info("Transcription result: %s", transcription_result)

    except requests.exceptions.RequestException as e:
        print(str(e))
        logger.error(f"Request error: {str(e)}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, "faster_whisper_api",trace_str, 'ERROR', str(e))
        raise HTTPException(status_code=500, detail="An error occurred during transcription")
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        trace_str = traceback.format_exc()
        print(str(e))
        log_to_db(id, trace_id, "faster_whisper_api",trace_str, 'ERROR',str(e))
        raise HTTPException(status_code=500, detail="An unexpected error occurred")
    
    new_transcript = ""
    if transcription_result.status_code == 200:
        for segment in transcription_result.json().get("segments", []):
            if "Thanks for watching" not in segment.get("text", ""):
                new_transcript += segment.get("text", "") + "\n"

    entity_extraction_url = f"http://entity_extraction_api_groq:8009/extract_entities/{id}"
    data = {"query": new_transcript}
    try:
        response = requests.post(entity_extraction_url, json=data, headers=header)
        response.raise_for_status()
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id,"entity_extraction_api_groq", trace_str, 'SUCCESS', transcription_result)
        logger.info("Entity extraction result: %s", response.json())
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {str(e)}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id,"entity_extraction_api_groq",trace_str, 'ERROR', str(e))
        raise HTTPException(status_code=500, detail="An error occurred during entity extraction")
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id,"entity_extraction_api_groq", trace_str, 'ERROR', str(e))
        raise HTTPException(status_code=500, detail="An unexpected error occurred")
    return response.json()

@router.get("/logs")
async def get_logs():
    db = SessionLocal()
    logs = db.query(Log).all()
    log_list = [{"trace_id": log.trace_id, "apiname":str(log.apiname), "timestamp": str(log.timestamp), "level": log.level, "message": log.message}
                for log in logs]
    db.close()
    return JSONResponse(content=log_list)

@router.get("/accuracy_logs")
async def get_logs():
    db = SessionLocal()
    logs = db.query(Log).all()
    log_list = [{"trace_id": log.trace_id, "apiname": str(log.apiname), "timestamp": str(log.timestamp), "level": log.level, "message": log.message}
                for log in logs]
    db.close()

    # Group logs by trace_id
    trace_id_logs = {}
    for log in log_list:
        if log["trace_id"] not in trace_id_logs:
            trace_id_logs[log["trace_id"]] = []
        trace_id_logs[log["trace_id"]].append(log)

    # Count success and error logs for each trace_id and calculate accuracy
    result = []
    for trace_id, logs in trace_id_logs.items():
        success_count = sum(1 for log in logs if log["level"] == "success")
        error_count = len(logs) - success_count
        accuracy = success_count / len(logs) if len(logs) > 0 else 0
        result.append({
            "trace_id": trace_id,
            "success_count": success_count,
            "error_count": error_count,
            "accuracy": accuracy
        })

    return JSONResponse(content=result)

# Class for uilogs
class LogEntry(BaseModel):
    trace_id: str
    source: str
    timestamp: datetime = datetime.utcnow()
    level: str
    message: str

@router.post("/uilogs")
async def insert_log(log_entry: LogEntry):
    db = SessionLocal()
    try:
        new_log = Log(
            trace_id=log_entry.trace_id,
            apiname=log_entry.source,
            id= str(uuid.uuid4()),  # Generating an ID
            timestamp=log_entry.timestamp,
            level=log_entry.level,
            message=log_entry.message,
        )
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        return JSONResponse(content={"message": "Log inserted successfully"})
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        db.close()