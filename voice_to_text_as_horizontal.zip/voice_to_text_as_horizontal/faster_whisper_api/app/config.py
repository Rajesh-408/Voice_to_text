from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    ALLOW_ORIGINS: list = ["*"]
    ALLOW_METHODS: list = ["GET", "POST"]
    ALLOW_HEADERS: list = ["Accept", "Content-Type"]
    MODEL_PATH: str = "./app/small_en"
    DEVICE: str = "auto"
    COMPUTE_TYPE: str = "int8"

settings = Settings()