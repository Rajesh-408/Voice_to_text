from fastapi import APIRouter, UploadFile, File, HTTPException, Header
from .utils import save_file, transcribe_audio
from fastapi.responses import JSONResponse
from sqlalchemy import Column, Integer, String, DateTime, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import logging, os, traceback, uuid
from fastapi import Request
from typing import Optional

PATH = "C:/Applicationlogs" # DIRECTORY PATH to generate the logs file locally
# logger = logging.getLogger(__name__)
router = APIRouter()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
os.makedirs(PATH,exist_ok=True)
dbpath = os.path.join(PATH, 'test.db')
txtpath = os.path.join(PATH, 'logger.txt')
DATABASE_URL = f"sqlite:///{dbpath}"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Log(Base):
    __tablename__ = "logs"
    trace_id = Column(String, index=True)
    apiname = Column(String, index=True)
    id = Column(String , primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String, index=True)
    message = Column(String, index=True)

Base.metadata.create_all(bind=engine)

def log_to_db(id, trace_id, line_info, level, message):
    try:
        with SessionLocal() as db:
            time = datetime.now()
            log_entry = Log(trace_id=trace_id, apiname="faster_whisper",id=str(uuid.uuid4()), timestamp=time, level=level, message=str(message))
            format = f'{trace_id}-------{"faster_whisper"}-------{time}-------{level}-------line_no:{line_info}-------{message}\n'
            with open(txtpath, 'a') as file:
                file.write(format)
            db.add(log_entry)
            db.commit()
    except Exception as e:
        print(f"An error occurred: {e}")

@router.post("/transcribe/")
async def transcribe(headers_request: Request,file: UploadFile = File(...),trace_id : str = Header(None)):
    headers_dict = dict(headers_request.headers)
    headers_trace_id = headers_dict.get("trace_id")
    if headers_trace_id is None:
        logger.info(f"trace_id for this request : {trace_id}")
    else:
        trace_id=headers_trace_id
        logger.info(f"trace_id for this request : {trace_id}")
    try:
        temp_file_path = save_file(file)
        transcription = transcribe_audio(temp_file_path)
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, trace_str, 'SUCCESS', transcription)
        return transcription
    except Exception as e:
        logger.error(f"Error during transcription: {str(e)}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, trace_str, 'ERROR', e.detail)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/logs")
async def get_logs():
    db = SessionLocal()
    logs = db.query(Log).all()
    log_list = [{"trace_id": log.trace_id, "apiname":str(log.apiname), "timestamp": str(log.timestamp), "level": log.level, "message": log.message}
                for log in logs]
    db.close()
    return JSONResponse(content=log_list)