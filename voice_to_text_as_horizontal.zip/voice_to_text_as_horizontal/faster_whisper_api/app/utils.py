from fastapi import UploadFile
import shutil
import os
from faster_whisper import WhisperModel
from .config import settings
import logging

logger = logging.getLogger(__name__)

model = WhisperModel(settings.MODEL_PATH, device=settings.DEVICE, compute_type=settings.COMPUTE_TYPE)

def save_file(file: UploadFile) -> str:
    temp_file_path = f"temp_{file.filename}"
    with open(temp_file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    logger.info(f"File saved to {temp_file_path}")
    return temp_file_path

def transcribe_audio(file_path: str) -> dict:
    segments, info = model.transcribe(file_path, beam_size=5)
    os.remove(file_path)
    logger.info(f"Transcription successful for {file_path}")
    return {
        "language": info.language,
        "language_probability": info.language_probability,
        "segments": [
            {
                "start": segment.start,
                "end": segment.end,
                "text": segment.text
            } for segment in segments
        ]
    }