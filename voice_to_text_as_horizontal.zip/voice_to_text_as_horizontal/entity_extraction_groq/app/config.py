import os
from dotenv import load_dotenv
from llama_index.llms.groq import Groq

load_dotenv()

groq_api_key = os.getenv("GROQ_API_KEY")
llm = Groq(model=os.getenv("MODEL_NAME"), api_key=groq_api_key)


prompt_template_str = """\
You are an expert data parser. Parse data from user query.

If you don't know any field then set it to null.

{query}
"""