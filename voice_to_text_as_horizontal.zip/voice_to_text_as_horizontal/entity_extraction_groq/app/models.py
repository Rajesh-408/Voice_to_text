from pydantic import BaseModel, Field
from typing import Union, Optional, List
from enum import Enum
from datetime import datetime


class PlanMaterialsHardCopyOptions(str, Enum):
    ANOC = "Required notices including Annual Notice of Change (ANOC)"
    EOB = "Explanation of Benefits (EOB)"
    MONTHLY_BILL = "Monthly Bill"

class RaceOptions(str, Enum):
    AMERICAN_INDIAN_OR_ALASKA_NATIVE = "American Indian or Alaska Native"
    ASIAN_INDIAN = "Asian Indian"
    BLACK_OR_AFRICAN_AMERICAN = "Black or African American"
    CHINESE = "Chinese"
    FILIPINO = "Filipino"
    GUAMANIAN_OR_CHAMORRO = "Guamanian or Chamorro"
    JAPANESE = "Japanese"
    KOREAN = "Korean"
    NATIVE_HAWAIIAN = "Native Hawaiian"
    OTHER_ASIAN = "Other Asian"
    OTHER_PACIFIC_ISLANDER = "Other Pacific Islander"
    SAMOAN = "Samoan"
    VIETNAMESE = "Vietnamese"
    WHITE = "White"
    I_CHOOSE_NOT_TO_ANSWER = "I choose not to answer"

class OriginOptions(str, Enum):
    NOT_HISPANIC = "No, not of Hispanic, Latino/a, or Spanish origin"
    MEXICAN = "Yes, Mexican, Mexican American, Chicano/a"
    PUERTO_RICAN = "Yes, Puerto Rican"
    CUBAN = "Yes, Cuban"
    OTHER_HISPANIC = "Yes, another Hispanic, Latino/a, or Spanish origin"
    CHOOSE_NOT_TO_ANSWER = "I choose not to answer"

class RentDMEOptions(str, Enum):
    ELECTRIC_WHEELCHAIR = "Electric Wheelchair"
    WHEELCHAIR = "Wheelchair"
    HOSPITAL_BED = "Hospital Bed"
    CPAP = "CPAP"
    LIFT = "Lift"
    OXYGEN = "Oxygen"
    NEBULIZER = "Nebulizer"
    OTHER_EQUIPMENT_NAME = "Other equipment name"


#page2 --- PremiumPaymentOption,TypeOfAccount,SsnOrRrb
    
class PremiumPaymentOption(str, Enum):
    MONTHLY_BILL = "Monthly Bill - Digital or Paper"
    AUTOMATIC_BANK_EFT = "Automatic Monthly Bank Account Deduction (EFT)- Enter bank information below"
    AUTOMATIC_DEDUCTION_SSN_OR_RRB = "Automatic deduction from your monthly Social Security/Railroad Retirement Board benefit check"

class TypeOfAccount(str,Enum):
    CHECKING = "Checking"
    SAVINGS= "Savings"

class SsnOrRrb(str,Enum):
    SOCIAL_SECURITY = "Social Security"
    RAILROAD_RETIREMENT_BOARD= "Railroad Retirement Board (RRB)"

# class RentDMEOptions(Enum):
#     ELECTRIC_WHEELCHAIR = 1
#     WHEELCHAIR = 2
#     HOSPITAL_BED = 3
#     CPAP = 4
#     LIFT = 5
#     OXYGEN = 6
#     NEBULIZER = 7
#     OTHER_EQUIPMENT = 8

class ChoosePCPOptions(str, Enum):
    SEARCH_FOR_DOCTOR_OR_FACILITIES = "Search For Doctors/Facilities"
    ENTER_PCP_INFO = "Enter PCP Information"
    NO_PREFERENCE = "No Preference"

# For Page4 EligibilityOptions
class EligibilityOptions(str, Enum):
    AEP = "Enrolling during Annual Open Enrollment Period (AEP) from October 15 to December 7. (AEP)."
    NEW_TO_MEDICARE = "New to Medicare (IEP/ICEP)."
    TURNING_65 = "Turning 65 and not new to Medicare (IEP2)."
    QUALIFYING_CONDITION = "Have a qualifying condition.(SEP)"
    MOVED_OUTSIDE_SERVICE_AREA = "Recently moved outside service area for current plan or recently moved and this plan is a new option (SEP)."
    MEDICARE_MEDICAID = "Have both Medicare and Medicaid (or state helps pay for Medicare premiums) or Get Extra Help paying for Medicare prescription drug coverage, but haven't had a change.(SEP)"
    ENROLLED_BY_MEDICARE = "Enrolled in a plan by Medicare (or state) and want to choose a different plan (SEP)"
    AFFECTED_BY_DISASTER = "Affected by an emergency or major disaster (as declared by the Federal Emergency Management Agency (FEMA) or by a Federal, state or local government entity). One of the other statements here applied, but was unable to enroll because of the disaster. (SEP)"
    CHANGE_IN_MEDICAID = "Moving into, live in or recently moved out of a long-term care facility (for example, a nursing home or long-term care facility) (SEP)"
    LONG_TERM_CARE = "Moving into, live in or recently moved out of a long-term care facility (for example, a nursing home or long-term care facility) (SEP)"
    LEFT_PACE_PROGRAM = "Recently left a Program of All-inclusive Care for the Elderly (PACE®) program (SEP)"
    LOST_CREDITABLE_COVERAGE = "Recently involuntarily lost creditable prescription drug coverage (coverage as good as Medicare’s) (SEP)"
    LEAVING_EMPLOYER_COVERAGE = "Leaving employer or union coverage (SEP)"
    PHARMACY_ASSISTANCE_PROGRAM = "Belong to a pharmacy assistance program provided by state. (SEP)"
    RETURNED_TO_US = "Recently returned to the United States after living permanently outside of the U.S (SEP)"
    PLAN_ENDING_CONTRACT = "Plan ending its contract with Medicare or Medicare ending its contract with current plan. (SEP) (SEP)"
    LOST_SNP_QUALIFICATION = "Enrolled in a Special Needs Plan (SNP) but lost the special needs qualification required to be in that plan. (SEP)"
    RELEASED_FROM_INCARCERATION = "Recently released from incarceration (SEP)"
    LAWFUL_PRESENCE_STATUS = "Recently obtained lawful presence status in the United States (SEP)"
    MA_OEP_CHANGE = "Recently obtained lawful presence status in the United States (SEP)Enrolled in a Medicare Advantage plan and want to make a change during the Medicare Advantage Open Enrollment Period.(MA OEP)"
    OTHER = "Other"

# For Page5 EssentialExtrasOptions
class EssentialExtrasOptions(str, Enum):
    EVERYDAY_OPTIONS = "Everyday Options Allowance for Dental, Vision, and Hearing-$500 annual allowance"
    ASSISTIVE_DEVICES = "Assistive Devices-$500 annual allowance"
    TRANSPORTATION = "Transportation-60 One-Way Trips"
    UTILITIES = "Utilities-$150 per quarter towards utilities"

# For Page6 AppointmentType, ScopeOfAppointment, ApplicantSignature
class AppointmentType(str, Enum):
    FACE_TO_FACE = "Face-to-face"
    TELEPHONE = "Telephone"
    WEBCAM = "Webcam"
    NOT_COLLECTED = "Not collected"

class ScopeOfAppointment(str, Enum):
    PAPER = "Paper"
    ELECTRONIC = "Electronic"
    RECORDED_CALL = "Recorded call"

class ApplicantSignature(str, Enum):
    VOICE_SIGNATURE = "Voice Signature"
    PAPER_APPLICATION = "Paper Application"
    SIGNATURE_PAD = "Signature Pad"

class Person(BaseModel):
    name: Optional[str] = Field(description="Name of the Person")
    age: Optional[int] = Field(description="Age of the Person")
    height: Optional[str] = Field(description="Height of the Person")


class People(BaseModel):
    people: List[Person] = Field(description="List of People")
    
class NavigationActions(BaseModel):
    next_page: Optional[bool] = Field(description="True only when applicant says 'Navigate to next page'")
    previous_page: Optional[bool] = Field(description="True only when applicant says 'Navigate to previous page'")
    save_page: Optional[bool] = Field(description="True only when applicant says 'Save the page'")
    scroll_down: Optional[bool] = Field(description="True only when applicant says 'Scroll down'")
    scroll_up: Optional[bool] = Field(description="True only when applicant says 'Scroll up'")
    scroll_to_bottom: Optional[bool] = Field(description="True only when applicant says 'Scroll to bottom'")
    scroll_to_top: Optional[bool] = Field(description="True only when applicant says 'Scroll to top'")
    go_to_page: Optional[int] = Field(description="Page number to navigate to when applicant says 'Go to page X'")


class PageOne(BaseModel):
    last_name: Optional[str] = Field(description="last name of the applicant")
    first_name: Optional[str] = Field(description="first name of the applicant")
    gender: Optional[str] = Field(description="whether applicant is 'male' or 'female'")
    date_of_birth: Optional[str] = Field(description="extract date of birth of applicant in mm/dd/yyyy format")
    phone: Optional[str] = Field(description="Phone number of the applicant. Give in format xxx-xxx-xxxx")
    alternate_phone: Optional[str] = Field(description="Alternate phone of the applicant")
    email: Optional[str] = Field(description="Email of the applicant")
    receive_plan_material_hard_copies_via_mail: Optional[List[PlanMaterialsHardCopyOptions]] = Field(description="Which plan material hard copies should be sent via mail.") #Should be strictly from this list of options only: [1. 'Required notices including Annual Notice of Change (ANOC)', 2. 'Explanation of Benefits (EOB)', 3. 'Monthly Bill'] ")
    # receive_plan_material_hard_copies_via_mail: Optional[List[int]] = Field(description="Which plan material hard copies should be sent via mail. Should be strictly from this list of options only: [1. 'Required notices including Annual Notice of Change (ANOC)', 2. 'Explanation of Benefits (EOB)', 3. 'Monthly Bill'] ")
    question_1: Optional[List[int]] = Field(description="User selected options for question 1")
    address_1: Optional[str] = Field(description="Home address 1 of the applicant")
    address_2: Optional[str] = Field(description="Home address 2 of the applicant")
    county: Optional[str] = Field(description="County of the applicant")
    city: Optional[str] = Field(description="City of the applicant")
    state: Optional[str] = Field(description="State of the applicant")
    zipcode: Optional[int] = Field(description="Zipcode of the applicant")
    different_mailing_address: Optional[bool] = Field(description="Different mailing address or not.")
    mailing_address_1: Optional[str] = Field(description="mailing or billing address 1 of the applicant")
    mailing_address_2: Optional[str] = Field(description="mailing or billing address 2 of the applicant")
    mailing_city: Optional[str] = Field(description="mailing or billing City of the applicant")
    mailing_state: Optional[str] = Field(description="mailing or billing State code of the applicant. This should be two letter US state code.")
    mailing_zipcode: Optional[str] = Field(description="mailing or billing Zipcode of the applicant.")
    medicare_number: Optional[str] = Field(description="Medicare number of the applicant")
    part_a_effective_date: Optional[str] = Field(description="hospital or part-a effective date. Need this in mm/yyyy format.")
    part_b_effective_date: Optional[str] = Field(description="medical or part-b effective date. Need this in mm/yyyy format.")
    origin: Optional[List[OriginOptions]] = Field(description="Origin of the applicant.") #Should be strictly from this list of options only: [1. No, not of Hispanic, Latino/a, or Spanish origin 2. Yes, Mexican, Mexican American, Chicano/a 3. Yes, Puerto Rican 4. Yes, Cuban 5. Yes, another Hispanic, Latino/a, or Spanish origin 6. I choose not to answer]")
    # origin: Optional[List[int]] = Field(description="Origin options of the Applicant. Should be strictly from this list of options only: [1. No, not of Hispanic, Latino/a, or Spanish origin 2. Yes, Mexican, Mexican American, Chicano/a 3. Yes, Puerto Rican 4. Yes, Cuban 5. Yes, another Hispanic, Latino/a, or Spanish origin 6. I choose not to answer]")
    question_2: Optional[List[int]] = Field(description="User selected options for question 2")
    race: Optional[List[RaceOptions]] = Field(description="Race options of the Applicant.") #Should be strictly from this list of options only: [1. American Indian or Alaska Native 2. Asian Indian 3. Black or African American 4. Chinese 5. Filipino 6. Guamanian or Chamorro 7. Japanese 8. Korean 9. Native Hawaiian 10. Other Asian 11. Other Pacific Islander 12. Samoan 13. Vietnamese 14. White 15. I choose not to answer]")
    # race: Optional[List[int]] = Field(description="Race options of the Applicant. Should be strictly from this list of options only: [1. American Indian or Alaska Native 2. Asian Indian 3. Black or African American 4. Chinese 5. Filipino 6. Guamanian or Chamorro 7. Japanese 8. Korean 9. Native Hawaiian 10. Other Asian 11. Other Pacific Islander 12. Samoan 13. Vietnamese 14. White 15. I choose not to answer]")
    question_3: Optional[List[int]] = Field(description="User selected options for question 3")
    # question_3: Optional[List[int]] = Field(description="Race options of the Applicant for Question 3. Should be strictly from this list of options only: [1. American Indian or Alaska Native 2. Asian Indian 3. Black or African American 4. Chinese 5. Filipino 6. Guamanian or Chamorro 7. Japanese 8. Korean 9. Native Hawaiian 10. Other Asian 11. Other Pacific Islander 12. Samoan 13. Vietnamese 14. White 15. I choose not to answer]")
    send_information_in_spanish: Optional[bool] = Field(description="Send information in spanish or not")
    question_4: Optional[List[int]] = Field(description="User selected options for question 4")
    information_accessible_format: Optional[str] = Field(description="Information accessible format. Should be from these options only: 'Voice-Enabled (Audio) PDF' or 'Large Print'")
    question_5: Optional[int] = Field(description="User selected option for question 5. Should be either 1 or 2")
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")

    class Config:
        use_enum_values = True

# class CareNeeds(BaseModel):
    # planned_procedure_or_surgery: Optional[bool] = Field(description="Is there any Planned procedure or surgery")
    # question_3_1: Optional[bool] = Field(description="User selected options for question 3.1 from options 'yes' or 'no'")
    # procedure_or_surgery_treatment_details: Optional[str] = Field(description="Details of the procedure or surgery")
    # rent_dme: Optional[bool] = Field(description="Rent durable medical equipment or not")
    # question_3_2: Optional[bool] = Field(description="User selected options for question 3.2 from options 'yes' or 'no'")
    # which_dme_on_rent: Optional[list[RentDMEOptions]] = Field(description="Which durable medical equipments are rented")
    # use_dme_vendor: Optional[bool] = Field(description="Use durable medical equipment vendor or not")
    # question_3_3: Optional[bool] = Field(description="User selected options for question 3.3 from options 'yes' or 'no'")
    # name_of_dme_vendor: Optional[str] = Field(description="Name of the durable medical equipment vendor")
    # phone_of_dme_vendor: Optional[str] = Field(description="Phone number of the durable medical equipment vendor")
    # address1_of_dme_vendor: Optional[str] = Field(description="Address1 of the durable medical equipment vendor")
    # address2_of_dme_vendor: Optional[str] = Field(description="Address2 of the durable medical equipment vendor")
    # city_of_dme_vendor: Optional[str] = Field(description="City of the durable medical equipment vendor")
    # state_code_of_dme_vendor: Optional[str] = Field(description="Two letter State code of the durable medical equipment vendor")
    # zipcode_of_dme_vendor: Optional[str] = Field(description="Zipcode of the durable medical equipment vendor")
    # have_current_pcp: Optional[bool] = Field(description="Have current primary care physician or not")
    # question_3_4: Optional[bool] = Field(description="User selected options for question 3.4 from options 'yes' or 'no'")
    # first_name_of_current_pcp: Optional[str] = Field(description="First Name of the current primary care physician")
    # last_name_of_current_pcp: Optional[str] = Field(description="Last Name of the current primary care physician")
    # phone_of_current_pcp: Optional[str] = Field(description="Phone number of the current primary care physician")
    # have_treating_specialist: Optional[bool] = Field(description="Have treating specialist or not")
    # question_3_5: Optional[bool] = Field(description="User selected options for question 3.5 from options 'yes' or 'no'")
    # first_name_of_treating_specialist: Optional[str] = Field(description="First Name of the treating specialist")
    # last_name_of_treating_specialist: Optional[str] = Field(description="Last Name of the treating specialist")
    # phone_of_treating_specialist: Optional[str] = Field(description="Phone number of the treating specialist")
    # speciality_of_treating_specialist: Optional[str] = Field(description="Speciality of the treating specialist")
    # have_current_dialysis_center: Optional[bool] = Field(description="Have current dialysis center or not")
    # question_3_6: Optional[bool] = Field(description="User selected options for question 3.6 from options 'yes' or 'no'")
    # name_of_current_dialysis_center: Optional[str] = Field(description="Name of the current dialysis center")
    # phone_of_current_dialysis_center: Optional[str] = Field(description="Phone number of the current dialysis center")
    # address1_of_current_dialysis_center: Optional[str] = Field(description="Address1 of the current dialysis center")
    # address2_of_current_dialysis_center: Optional[str] = Field(description="Address2 of the current dialysis center")
    # city_of_current_dialysis_center: Optional[str] = Field(description="City of the current dialysis center")
    # state_code_of_current_dialysis_center: Optional[str] = Field(description="Two letter State code of the current dialysis center")
    # zipcode_of_current_dialysis_center: Optional[str] = Field(description="Zipcode of the current dialysis center")
    # have_in_home_skilled_nursing: Optional[bool] = Field(description="Have in home skilled nursing or not")
    # question_3_7: Optional[bool] = Field(description="User selected options for question 3.7 from options 'yes' or 'no'")
    # have_in_home_physical_or_occupational_or_speech_therapy: Optional[bool] = Field(description="Have in home physical or occupational or speech therapy or not")
    # question_3_8: Optional[bool] = Field(description="User selected options for question 3.8 from options 'yes' or 'no'")
    # in_home_provider_name: Optional[str] = Field(description="Name of the in home provider")
    # in_home_provider_phone: Optional[str] = Field(description="Phone number of the in home provider")
    # notes: Optional[str] = Field(description="Notes")

# class CSNPPrequalificationForm(BaseModel):
    # congestive_heart_failure: Optional[bool] = Field(description="Applicant has Congestive heart failure(CHF) or not")
    # question_8: Optional[bool] = Field(description="User selected options for question 8 from options 'yes' or 'no'")
    # cardiovascular_disease: Optional[bool] = Field(description="Applicant has Cardiovascular disease(CVD) or not")
    # question_9: Optional[bool] = Field(description="User selected options for question 9 from options 'yes' or 'no'")
    # diabetes: Optional[bool] = Field(description="Applicant has Diabetes or not")
    # question_10: Optional[bool] = Field(description="User selected options for question 10 from options 'yes' or 'no'")
    # chronic_lung_disorder: Optional[bool] = Field(description="Applicant has Chronic lung disorder or not")
    # question_11: Optional[bool] = Field(description="User selected options for question 11 from options 'yes' or 'no'")
    # end_stage_renal_disease: Optional[bool] = Field(description="Applicant has End stage renal disease(ESRD) or not")
    # question_12: Optional[bool] = Field(description="User selected options for question 12 from options 'yes' or 'no'")
    # name_of_current_dialysis_center: Optional[str] = Field(description="Name of the current dialysis center")
    # phone_of_current_dialysis_center: Optional[str] = Field(description="Phone number of the current dialysis center")
    # identification_number_of_dialysis_center: Optional[str] = Field(description="Identification number of the current dialysis center")
    # nephrologist_name: Optional[str] = Field(description="Name of the nephrologist")
    # nephrologist_phone: Optional[str] = Field(description="Phone number of the nephrologist")
    # provider_first_name: Optional[str] = Field(description="First name of the provider")
    # provider_last_name: Optional[str] = Field(description="Last name of the provider")
    # provider_phone: Optional[str] = Field(description="Phone number of the provider")
    # provider_fax: Optional[str] = Field(description="Fax number of the provider")
    # provider_address1: Optional[str] = Field(description="Address1 of the provider")


class PageTwo(BaseModel):
    add_payment_preference: Optional[bool] = Field(description="add payment preference, Yes or No")
    premium_payment_option:Optional[PremiumPaymentOption]= Field(description="select a premium payment option")
    type_of_account:Optional[TypeOfAccount]=Field(description="Select type of account")
    account_holder_name: Optional[str] = Field(description="Name of the account holder")
    bank_name: Optional[str] = Field(description="Name of the bank")
    bank_account_number: Optional[str] = Field(description="Bank account number")
    bank_routing_number: Optional[str] = Field(description="Bank routing number")

    deduction_from_social_security_or_rrb: Optional[SsnOrRrb] = Field(description="select social security or railroad retirement board(rrb)")
    has_other_prescription_coverage: Optional[bool] = Field(description="Has other prescription coverage or not")
    question_1: Optional[bool] = Field(description="User selected options for question 1 from options 'yes' or 'no'")
    other_coverage_name: Optional[str] = Field(description="Name of the other coverage")
    member_number_of_other_coverage: Optional[str] = Field(description="Member number of the other coverage")
    group_number_of_other_coverage: Optional[str] = Field(description="Group number of the other coverage")
    other_coverage_start_date: Optional[str] = Field(description="Start date of the other coverage. This should be in mm/dd/yyyy format.")
    other_coverage_end_date: Optional[str] = Field(description="End date of the other coverage. This should be in mm/dd/yyyy format.")
    receiving_skilled_nursing_services: Optional[bool] = Field(description="Receiving skilled nursing services or not")
    question_2: Optional[bool] = Field(description="User selected options for question 2 from options 'yes' or 'no'")
    have_continuity_of_care_needs: Optional[bool] = Field(description="Have continuity of care needs or not")
    question_3: Optional[bool] = Field(description="User selected options for question 3 from options 'yes' or 'no'")
    
    # care_needs: Optional[CareNeeds] = Field(description="Care needs of the applicant")
    planned_procedure_or_surgery: Optional[bool] = Field(description="Is there any Planned procedure or surgery")
    question_3_1: Optional[bool] = Field(description="User selected options for question 3.1 from options 'yes' or 'no'")
    procedure_or_surgery_treatment_details: Optional[str] = Field(description="Details of the procedure or surgery")
    rent_dme: Optional[bool] = Field(description="Rent durable medical equipment or not")
    question_3_2: Optional[bool] = Field(description="User selected options for question 3.2 from options 'yes' or 'no'")
    which_dme_on_rent: Optional[list[RentDMEOptions]] = Field(description="Which durable medical equipments are rented.") #Should be strictly from given list of options: [1. Electric Wheelchair 2. Wheelchair 3. Hospital Bed 4. CPAP 5. Lift 6. Oxygen 7. Nebulizer 8. Other equipment name]")
    # which_dme_on_rent: Optional[list[int]] = Field(description="Which durable medical equipments are rented. Should be strictly from given list of options: [1. Electric Wheelchair 2. Wheelchair 3. Hospital Bed 4. CPAP 5. Lift 6. Oxygen 7. Nebulizer 8. Other equipment name]")
    use_dme_vendor: Optional[bool] = Field(description="Use durable medical equipment vendor or not")
    question_3_3: Optional[bool] = Field(description="User selected options for question 3.3 from options 'yes' or 'no'")
    name_of_dme_vendor: Optional[str] = Field(description="Name of the durable medical equipment vendor")
    phone_of_dme_vendor: Optional[str] = Field(description="Phone number of the durable medical equipment vendor")
    address1_of_dme_vendor: Optional[str] = Field(description="Address1 of the durable medical equipment vendor")
    address2_of_dme_vendor: Optional[str] = Field(description="Address2 of the durable medical equipment vendor")
    city_of_dme_vendor: Optional[str] = Field(description="City of the durable medical equipment vendor")
    state_code_of_dme_vendor: Optional[str] = Field(description="Two letter State code of the durable medical equipment vendor")
    zipcode_of_dme_vendor: Optional[str] = Field(description="Zipcode of the durable medical equipment vendor")
    have_current_pcp: Optional[bool] = Field(description="Have current primary care physician or not")
    question_3_4: Optional[bool] = Field(description="User selected options for question 3.4 from options 'yes' or 'no'")
    first_name_of_current_pcp: Optional[str] = Field(description="First Name of the current primary care physician")
    last_name_of_current_pcp: Optional[str] = Field(description="Last Name of the current primary care physician")
    phone_of_current_pcp: Optional[str] = Field(description="Phone number of the current primary care physician. Give in format xxx-xxx-xxxx")
    have_treating_specialist: Optional[bool] = Field(description="Have treating specialist or not")
    question_3_5: Optional[bool] = Field(description="User selected options for question 3.5 from options 'yes' or 'no'")
    first_name_of_treating_specialist: Optional[str] = Field(description="First Name of the treating specialist")
    last_name_of_treating_specialist: Optional[str] = Field(description="Last Name of the treating specialist")
    phone_of_treating_specialist: Optional[str] = Field(description="Phone number of the treating specialist")
    speciality_of_treating_specialist: Optional[str] = Field(description="Speciality of the treating specialist")
    have_current_dialysis_center: Optional[bool] = Field(description="Have current dialysis center or not")
    question_3_6: Optional[bool] = Field(description="User selected options for question 3.6 from options 'yes' or 'no'")
    name_of_current_dialysis_center: Optional[str] = Field(description="Name of the current dialysis center")
    phone_of_current_dialysis_center: Optional[str] = Field(description="Phone number of the current dialysis center")
    address1_of_current_dialysis_center: Optional[str] = Field(description="Address1 of the current dialysis center")
    address2_of_current_dialysis_center: Optional[str] = Field(description="Address2 of the current dialysis center")
    city_of_current_dialysis_center: Optional[str] = Field(description="City of the current dialysis center")
    state_code_of_current_dialysis_center: Optional[str] = Field(description="Two letter State code of the current dialysis center")
    zipcode_of_current_dialysis_center: Optional[str] = Field(description="Zipcode of the current dialysis center")
    have_in_home_skilled_nursing: Optional[bool] = Field(description="Have in home skilled nursing or not")
    question_3_7: Optional[bool] = Field(description="User selected options for question 3.7 from options 'yes' or 'no'")
    have_in_home_physical_or_occupational_or_speech_therapy: Optional[bool] = Field(description="Have in home physical or occupational or speech therapy or not")
    question_3_8: Optional[bool] = Field(description="User selected options for question 3.8 from options 'yes' or 'no'")
    in_home_provider_name: Optional[str] = Field(description="Name of the in home provider")
    in_home_provider_phone: Optional[str] = Field(description="Phone number of the in home provider")
    notes: Optional[str] = Field(description="Notes")

    applicant_or_spouse_work: Optional[bool] = Field(description="Applicant or spouse work or not")
    question_4: Optional[bool] = Field(description="User selected options for question 4 from options 'yes' or 'no'")
    veteran_status: Optional[str] = Field(description="Veteran status of the applicant. Value should be 'veteran' or 'not_veteran' or 'choose not to answer'")
    question_5: Optional[str] = Field(description="User selected options for question 5 from options 'veteran' or 'not_veteran' or 'choose not to answer'")
    interested_in_learning_about_prescription_home_delivery_program: Optional[bool] = Field(description="Interested in learning about prescription home delivery program or not")   
    question_6: Optional[bool] = Field(description="User selected options for question 6 from options 'yes' or 'no'")
    ever_diagnosed_with_chf_cvd_lung_disorder_diabetes: Optional[bool] = Field(description="Ever diagnosed with Congestive heart failure (CHF), Cardiovascular disease (CVD), Chronic lung disorder and/or Diabetes.")
    question_7: Optional[bool] = Field(description="User selected options for question 7 from options 'yes' or 'no'")

    # csnp_prequalication_form: Optional[CSNPPrequalificationForm] = Field(description="csnp prequalication responses of the applicant")
    congestive_heart_failure: Optional[bool] = Field(description="Applicant has Congestive heart failure(CHF) or not")
    question_8: Optional[bool] = Field(description="User selected options for question 8 from options 'yes' or 'no'")
    cardiovascular_disease: Optional[bool] = Field(description="Applicant has Cardiovascular disease(CVD) or not")
    question_9: Optional[bool] = Field(description="User selected options for question 9 from options 'yes' or 'no'")
    diabetes: Optional[bool] = Field(description="Applicant has Diabetes or not")
    question_10: Optional[bool] = Field(description="User selected options for question 10 from options 'yes' or 'no'")
    chronic_lung_disorder: Optional[bool] = Field(description="Applicant has Chronic lung disorder or not")
    question_11: Optional[bool] = Field(description="User selected options for question 11 from options 'yes' or 'no'")
    end_stage_renal_disease: Optional[bool] = Field(description="Applicant has End stage renal disease(ESRD) or not")
    question_12: Optional[bool] = Field(description="User selected options for question 12 from options 'yes' or 'no'")
    name_of_current_dialysis_center: Optional[str] = Field(description="Name of the current dialysis center")
    phone_of_current_dialysis_center: Optional[str] = Field(description="Phone number of the current dialysis center")
    identification_number_of_dialysis_center: Optional[str] = Field(description="Identification number of the current dialysis center")
    nephrologist_name: Optional[str] = Field(description="Name of the nephrologist")
    nephrologist_phone: Optional[str] = Field(description="Phone number of the nephrologist")
    provider_first_name: Optional[str] = Field(description="First name of the provider")
    provider_last_name: Optional[str] = Field(description="Last name of the provider")
    provider_phone: Optional[str] = Field(description="Phone number of the provider")
    provider_fax: Optional[str] = Field(description="Fax number of the provider")
    provider_address1: Optional[str] = Field(description="Address1 of the provider")
    
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")

    class Config:
        use_enum_values = True
    
class PageThree(BaseModel):
    preference_to_enter_pcp_info: Optional[ChoosePCPOptions] = Field(description="How do you prefer to enter primary care physician info. Search for one or enter one or no preference.")
    pcp_id: Optional[str] = Field(description="Primary care physician(PCP) ID")
    recently_visited_this_pcp_or_doctor: Optional[bool] = Field(description="Recently visited this primary care physician/doctor or not")
    provider_type: Optional[str] = Field(description="Provider type should be one of the following 'Doctor' or 'Facility'")
    provider_first_name: Optional[str] = Field(description="First name of the provider")
    provider_last_name: Optional[str] = Field(description="Last name of the provider")
    primary_medical_group_name: Optional[str] = Field(description="Primary medical group (PMG) name")
    provider_address1: Optional[str] = Field(description="Address1 of the provider")
    provider_city: Optional[str] = Field(description="City of the provider")
    provider_state_code: Optional[str] = Field(description="Two letter State code of the provider like for example CA for california.")
    provider_zipcode: Optional[str] = Field(description="Zipcode of the provider")
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")

class PageFour(BaseModel):
    # eligibility_options: Optional[List[EligibilityOptions]] = Field(description="List of eligibility options selected by the applicant.")
    eligibility_attestation_options: Optional[List[int]] = Field(description="User selected options for eligibility attestation.")
    # question_1: Optional[List[int]] = Field(description="User selected options for question 1")
    date_of_move: Optional[str] = Field(description="Date of move in mm/dd/yyyy format, if applicable.")
    date_of_enrollment: Optional[str] = Field(description="Date of enrollment in mm/dd/yyyy format, if applicable.")
    date_of_change: Optional[str] = Field(description="Date of change in mm/dd/yyyy format, if applicable.")
    date_of_drug_coverage_loss: Optional[str] = Field(description="Date of drug coverage loss in mm/dd/yyyy format, if applicable.")
    coverage_start_date: Optional[str] = Field(description="Coverage start date in mm/dd/yyyy format, if applicable.")
    coverage_end_date: Optional[str] = Field(description="Coverage end date in mm/dd/yyyy format, if applicable.")
    date_of_return_to_US: Optional[str] = Field(description="Date of return to US in mm/dd/yyyy format, if applicable.")
    date_of_disenrollment: Optional[str] = Field(description="Date of disenrollment from SNP plan in mm/dd/yyyy format, if applicable.")
    date_of_release: Optional[str] = Field(description="Date of release from incarceration in mm/dd/yyyy format, if applicable.")
    lawful_presence_status_date: Optional[str] = Field(description="Lawful presence status date in mm/dd/yyyy format, if applicable.")
    other_details: Optional[str] = Field(description="Additional details if 'Other' option is selected")
    authorized_person_first_name: Optional[str] = Field(description="First name of the authorized person")
    authorized_person_middle_initial: Optional[str] = Field(description="Middle initial of the authorized person")
    authorized_person_last_name: Optional[str] = Field(description="Last name of the authorized person")
    street_address1: Optional[str] = Field(description="Primary street address of the residence or business")
    street_address2: Optional[str] = Field(description="Secondary street address such as apartment or suite number")
    city: Optional[str] = Field(description="City of residence or business location")
    authorized_person_state_code: Optional[str] = Field(description="Two letter state code of authorised person.")
    zip_code: Optional[str] = Field(description="Postal zip code for area of residence or business")
    phone_number: Optional[str] = Field(description="Contact phone number including area code")
    relationship_to_enrollee: Optional[str] = Field(description="Relationship of the authorized person to the enrollee")
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")

class PageFive(BaseModel):
    essential_extra_options: Optional[List[EssentialExtrasOptions]] = Field(description="List of two essential extra options selected by the user")
    acknowledgement: Optional[bool] = Field(description="Acknowledge when applicant says 'I acknowledge'")
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")


class PageSix(BaseModel):
    appointment_type:Optional[AppointmentType]=Field(description="Type of appointment")
    scope_of_appointment:Optional[ScopeOfAppointment]=Field(description="Scope Of Appointment")
    recorded_call_details:Optional[str]=Field(description="what are the recorded call details")
    applicants_signature:Optional[ApplicantSignature]=Field(description="capture applicants signature")
    applicant_voice_id:Optional[str]=Field(description="Applicant Voice ID details")
    applicant_paper_signature:Optional[str]=Field(description="Wet signature on File")
    applicant_signature_pad:Optional[str]=Field(description="Enter Applicant Signature on signtaure pad")
    plan_transfer:Optional[bool]=Field(description="Is this a Plan transfer, Yes or No ")
    current_plan_details:Optional[str]=Field(description="what is the enrollee's current health plan?")
    application_help:Optional[bool]=Field(description="Helped the applicant to fill out the form, Yes or No ")
    first_name:Optional[str]=Field(description="First name of the applicant")
    middle_initial:Optional[str]=Field(description="Middle Initial of the applicant")
    last_name:Optional[str]=Field(description="Last name of the applicant")
    city:Optional[str]=Field(description="city of the applicant")
    state_code:Optional[str]=Field(description="Two letter state code")
    date_electronically_signed:Optional[str]=Field(description="date of the voice vault confirmation or applicant signature date. This should be in mm/dd/yyyy format.")
    submit:Optional[bool]=Field(description="submit the application, Yes or No" )
    navigation_actions: Optional[NavigationActions] = Field(description="Navigation actions of the applicant")


class QueryRequest(BaseModel):
    query: str = Field(description="Query to extract entities from")