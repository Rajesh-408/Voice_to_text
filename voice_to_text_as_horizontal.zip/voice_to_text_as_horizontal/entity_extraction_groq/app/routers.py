from fastapi import APIRouter, HTTPException, Depends, Header
from fastapi.responses import JSONResponse
from llama_index.core.program import LLMTextCompletionProgram
from llama_index.core.output_parsers import PydanticOutputParser
from functools import lru_cache

from app.models import *
from app.config import llm, prompt_template_str
from app.utils import parse_query
from sqlalchemy import Column, String, DateTime, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import logging, os, uuid, traceback
from fastapi import Request

PATH = "C:/Applicationlogs" # DIRECTORY PATH to generate the logs file locally
router = APIRouter()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

os.makedirs(PATH,exist_ok=True)
dbpath = os.path.join(PATH, 'test.db')
txtpath = os.path.join(PATH, 'logger.txt')
DATABASE_URL = f"sqlite:///{dbpath}"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Log(Base):
    __tablename__ = "logs"
    trace_id = Column(String, index=True)
    apiname = Column(String, index=True)
    id = Column(String , primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String, index=True)
    message = Column(String, index=True)

Base.metadata.create_all(bind=engine)

def log_to_db(id, trace_id, line_info, level, message):
    try:
        with SessionLocal() as db:
            time = datetime.now()
            log_entry = Log(trace_id=trace_id, apiname="entity_extraction_gorq",id=str(uuid.uuid4()), timestamp=time, level=level, message=str(message))
            format = f'{trace_id}-------{"entity_extraction_gorq"}-------{time}-------{level}-------line_no:{line_info}-------{message}\n'
            with open(txtpath, 'a') as file:
                file.write(format)
            db.add(log_entry)
            db.commit()
    except Exception as e:
        print(f"An error occurred: {e}")


def get_parser(model):
    return LLMTextCompletionProgram.from_defaults(
        output_parser=PydanticOutputParser(model),
        prompt_template_str=prompt_template_str,
        llm=llm
    )

pydantic_data_parsers = {
    0: {"model": People, "parser": get_parser(People)},
    1: {"model": PageOne, "parser": get_parser(PageOne)},
    2: {"model": PageTwo, "parser": get_parser(PageTwo)},
    3: {"model": PageThree, "parser": get_parser(PageThree)},
    4: {"model": PageFour, "parser": get_parser(PageFour)},
    5: {"model": PageFive, "parser": get_parser(PageFive)},
    6: {"model": PageSix, "parser": get_parser(PageSix)}
}

@lru_cache(maxsize=128)
def get_cached_parser_and_model(id: int):
    data = pydantic_data_parsers.get(id)
    if not data:
        raise ValueError(f"Invalid ID: {id}")
    return data["parser"], data["model"]

@router.post("/extract_entities/{id}")
async def extract_entities(headers_request: Request,id: int, request: QueryRequest,trace_id : str = Header(None)):
    logger.info(f"Received request to extract entities for ID: {id}")
    headers_dict = dict(headers_request.headers)
    headers_trace_id = headers_dict.get("trace_id")

    if headers_trace_id is None:
        logger.info(f"trace_id for this request : {trace_id}")
    else:
        trace_id=headers_trace_id
        logger.info(f"trace_id for this request : {trace_id}")
    try:
        parser, page_model = get_cached_parser_and_model(id)
    except ValueError as e:
        logger.error(str(e))
        raise HTTPException(status_code=400, detail=str(e))

    try:
        result = parse_query(request.query, parser)
        page_data = page_model(**result)
        logger.info(f"Successfully parsed query for ID: {id}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, trace_str, 'SUCCESS', JSONResponse(content=page_data.dict(exclude_none=True)))
        return JSONResponse(content=page_data.dict(exclude_none=True))
    except HTTPException as e:
        logger.error(f"HTTPException: {e.detail}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, trace_str, 'ERROR', e.detail)
        raise e
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        trace_str = traceback.format_exc()
        log_to_db(id, trace_id, trace_str, 'ERROR', str(e))
        raise HTTPException(status_code=500, detail="An unexpected error occurred")

@router.get("/logs")
async def get_logs():
    db = SessionLocal()
    logs = db.query(Log).all()
    log_list = [{"trace_id": log.trace_id, "apiname":str(log.apiname), "timestamp": str(log.timestamp), "level": log.level, "message": log.message}
                for log in logs]
    db.close()
    return JSONResponse(content=log_list)