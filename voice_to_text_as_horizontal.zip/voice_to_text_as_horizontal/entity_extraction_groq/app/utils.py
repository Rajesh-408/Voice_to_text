from fastapi import HTTPException
from functools import lru_cache
import logging

logger = logging.getLogger(__name__)

@lru_cache(maxsize=128)
def parse_query(query: str, pydantic_data_parser) -> dict:
    logger.info(f"Parsing query: {query}")
    try:
        response = pydantic_data_parser(query=query)
        logger.info("Query parsed successfully")
        return response.dict()
    except Exception as e:
        logger.error(f"Error parsing query: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))